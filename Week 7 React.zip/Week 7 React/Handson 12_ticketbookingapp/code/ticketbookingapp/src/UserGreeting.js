import React from 'react';

function GuestGreeting() {
  return <h1>Welcome back.</h1>;
}

export default GuestGreeting;
